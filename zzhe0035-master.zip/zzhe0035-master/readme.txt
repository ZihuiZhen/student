FIT5136 Readme for TA29

Xiaoshuang Li

Zihui Zhen

Hanqing Huang 31248462

test